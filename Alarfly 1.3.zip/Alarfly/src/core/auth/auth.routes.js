const { Router } = require('express');
const validate = require('../middlewares/validate');
const { loginSchema, acceptInvitationSchema, verifyTwoFactorSchema } = require('./auth.validator');
const authController = require('./auth.controller');

const router = Router();

router.post('/login', validate(loginSchema), authController.login);
router.post('/verify-2fa', validate(verifyTwoFactorSchema), authController.verifyTwoFactor);
router.post('/accept-invitation', validate(acceptInvitationSchema), authController.acceptInvitation);

module.exports = router;
